# Fortify GitLab CI Templates

Build secure software fast with [Fortify](https://www.microfocus.com/en-us/solutions/application-security). Fortify offers end-to-end application security solutions with the flexibility of testing on-premises and on-demand to scale and cover the entire software development lifecycle.  With Fortify, find security issues early and fix at the speed of DevOps. 

The Fortify GitLab CI Templates repository contains a collection of individual GitLab job .yml templates for integrating Fortify application security solutions into your GitLab CI/CD pipeline. These templates can be included directly into existing .gitlab-ci.yml definitions and are designed to be extensible through overridable variables. For more advanced use cases and customization, simply use the templates as a reference to get started.  


# General Usage
The easist way to get started is to directly include one or more reference templates into an existing .gitlab-ci.yml file. Each template uses variables to parameterize functionality and provide flexible configuration through use of overrides. When integrating any of the templates, here are some common considerations to keep in mind:
* Be sure to consider the appropriate job triggering rules when integrating application security testing, based on your project, branching strategy and release cadence. For example, users may choose to only perform comprehensive SAST analysis when merging or commiting changes to master or on a pre-defined schedule (daily, weekly, etc). DAST jobs should only be run after code is deployed as another example.
* Unless variables are explicitly defined in the reference template, the variables should exist in the GitLab Settings -> CI/CD configuration. Masked variables should be used wherever possible. If you use protected variables, be sure the branches where you want to execute the Fortify jobs are also marked as protected to avoid job failure.
* Review the default values in the templates and override to configure as appropriate for your project/environment.
* Consider using GitLab's cache functionality to optimize pipeline execution time, particularly when using the ScanCentral functionality for packaging code with Maven or Gradle builds.

# Available Templates
## Fortify ScanCentral SAST (fortify-sast-scancentral.yml)
Perform a comprehensive Static Application Security Testing (SAST) assessment using your on-premises Fortify ScanCentral environment. The fortify-sast-scancentral.yml template uses the Fortify ScanCentral client to prepare a zip file of the project source code and dependencies and then  start a SAST scan in Fortify Software Security Center/ScanCentral using the prepared payload. 

The invocation of the ScanCentral client should be modified to fit each individual project and CI/CD pipeline needs.  Please refer to the following resources for more information on customizing the template:
* [ScanCentral documentation](https://www.microfocus.com/documentation/fortify-software-security-center/)  

The template uses a Linux image and does not supoprt preparation of .NET, C/C++, and Swift/Objective-C technologies using ScanCentral. Fortify on-premises customers should utilize Fortify Static Code Analyzer (SCA) to integrate local translation and/or scanning on the GitLab runner.

Required GitLab CI/CD variables:
* $SSC_URL
* $SSC_TOKEN

# Fortify Static Code Analyzer usage
Fortify Static Code Analyzer 20.1.0.0158
Copyright (c) 2003-2020 Micro Focus or one of its affiliates
```
Usage:

  Clean:
     sourceanalyzer -b <build-id> -clean
  Build:
     sourceanalyzer -b <build-id> <sca-build-opts>
  Scan:
     sourceanalyzer -b <build-id> -scan <sca-scan-opts>

Detailed invocation:

  Build:
     sourceanalyzer -b <build-id>
          [ <sca-build-options> ]
          <file-specifier>
     sourceanalyzer -b <build-id>
          [ <sca-build-options> ]
          <compiler> <compiler-options>
     sourceanalyzer -b <build-id>
          [ <sca-build-options> ]
          touchless <build-tool> [ <build-tool-options> ]
     sourceanalyzer -b <build-id>
          [ <sca-build-options> ]
          devenv <solution-file> /REBUILD
     sourceanalyzer -b <build-id>
          [ <sca-build-options> ]
          msbuild /t:rebuild <solution-or-project-file>
     sourceanalyzer -b <build-id>
          [ <sca-build-options> ]
          xcodebuild -project <xcodeproj-file>
     sourceanalyzer -b mybuild
          -source-base-dir <webapp-root> <cfm-file-specifier>
  Scan:
     sourceanalyzer -b <build-id> -scan
          [ -f <output-file> ]
          [ -findbugs [ -java-build-dir <classes-dir> ] ]
          [ -rules <rules.xml> [ -no-default-rules ] ]
          [ -filter <filter-file> ]
  Clean:
     sourceanalyzer -b <build-id> -clean
  Query:
     sourceanalyzer -b <build-id> { -show-build-warnings | -show-files }
     sourceanalyzer { -version | -show-build-ids }
     sourceanalyzer { -h | -? | -help }



Options


General Options
These options are applicable to all sourceanalyzer invocations.

  @<file>                     Reads command line options from the specified
                              file.  Note that there is no space before the
                              file argument.

  -debug                      Causes the build step to write additional
                              troubleshooting information to the log file.
                              Use if instructed by Fortify Customer Support.
                              Also see "-logfile".

  -logfile <file>             Specifies a destination for the log file.

  -verbose                    Outputs verbose messages to the console.

  -Xmx<num>M                  Specifies the maximum Java heap size.
                              Default is -Xmx1800M.

  -autoheap                   Instructs SCA to set the maximum Java heap size
                              based on available physical memory. Use instead
                              of -Xmx.  Enabled by default.

  -version                    Shows the sourceanalyzer version.


Command Options
Note: Only one "command" option is allowed per invocation.


  -h                          Displays this help text.
  -help
  -?

  -clean                      Deletes all intermediate files and build records.
                              When a build ID is also specified with -b, only
                              files and build records related to that build ID
                              are deleted.

  -show-binaries              See the Fortify SCA User's Guide.
  -show-build-tree            See the Fortify SCA User's Guide.
  
  -show-build-ids             Lists all the Fortify build IDs (analysis models).

  -show-build-warnings        Displays all the actionable warnings that
                              occurred during the translation phase of the build
                              ID specified by "-b".

  -show-files                 Displays all the source files built into the model
                              specified by "-b".

  -show-loc                   Displays lines of code processed for files built
                              into the model specified by "-b".

  -scan                       Causes sourceanalyzer to run an analysis.

  (none)                      If no command option is present, a build step
                              is assumed.


Build Options
"Build" options translate source code into a Fortify analysis model.


  -b <build-id>               Specifies a unique name that identifies the
                              Fortify analysis model to be built. Also see
                              "-scan".

  -build-label <label>        Specifies an optional, arbitrary string value to
                              the Fortify analysis model. Will be included in
                              the output file.

  -build-project <project>    Specifies an optional, arbitrary string value to
                              the Fortify analysis model. Will be included in
                              the output file.

  -build-version <version>    Specifies an optional, arbitrary string value to
                              the Fortify analysis model. Will be included in
                              the output file.

  -encoding <encoding-name>   Specifies the source file encoding.
                              Default value is the platform default.

Compiler Integration Build Options
These options are used when integrating Fortify SCA with a compiler.

  <compiler> <compiler-opts>  Specifies the compiler command line. The file
                              being compiled will be added to the analysis
                              model, and the compiler will be invoked.

  touchless <build-tool>      Specifies a build tool command. The build tool
    [ <build-tool-options> ]  will be invoked, and any file being compiled
                              will be added to the analysis model.

  -nc                         When specified, the compiler is not invoked.


File Specification Build Options
These options are used to pass source files directly to Fortify SCA.

  <file-specifier>            Expression denoting a file or a group of files,
                              optionally matching a pattern:
                              file1.java - a file
                              file*.java - files matching expression
                              "path/**/*.java" - recursive expression matches.
                              Note: Always escape ** expressions in quotes.

  -exclude <file-specifier>   Excludes any files matched by <file-specifier>
                              from the set of files to translate 


Java-specific Build Options 
These options should be used in conjunction with file specification options.


  -classpath <classpath>      Uses the specified classpath value for Java
  -cp <classpath>             builds.

  -extdirs                    Accepts a colon or semicolon separated list
                              of directories.  Any jar files found in
                              these directories are included on the
                              classpath. Equivalent to the -extdirs option
                              to javac.

  -sourcepath                 Specifies the location of source files which will
                              not be included in the scan but will be used for
                              name resolution. Equivalent to the -sourcepath
                              option to javac.
                              The sourcepath is like classpath, except it uses
                              source files rather than class files for
                              resolution.

  -source <value>             Indicates which version of the Java language the
  -jdk <value>                Java code adheres to.  Valid values are 1.5, 1.6,
                              1.7, 1.8, 1.9, 5, 6, 7, 8, 9, 10, 11, 12, 13.
                              Default is "1.8".

  -java-build-dir <dir>       Used to specify one or more directories to which
                              Java sources are being compiled. May also be
                              specified at scan time.

Other Language-Specific Build Options

  -libdirs <dirs>             Accepts a colon or semicolon separated list of
                              directories where reference DLLs are located.
                              (For .NET builds).

  -dotnetwebroot <root>       The home directory of an ASP.Net project. For
                              .NET Web applications.

  -exclude-disabled-projects  Excludes any disabled projects in the solution
                              from the set of projects to translate.
                              (For .NET builds).

  -source-base-dir <root>     The base directory for a ColdFusion application.

  -python-path                Add an import directory for a Python application.

  -apex                       Set ".cls" file extension to Apex language.
                              (VB6 by default). The same if use
                              -Dcom.fortify.sca.fileextensions.cls=APEX

  -apex-sobject-path          Add file to load SObject types in Apex application.


Scan Options

  -b <build-id>               Specifies the build ID.  The build ID is used
                              to track which files are compiled and linked
                              as part of a build, to later scan those files.
                              This option may be specified more than once to
                              include multiple build IDs in the same scan.

  -bin <binary>               All source files compiled and linked into the
                              specified binary are scanned.  Multiple binaries
                              may be specified.

  -disable-default-rule-type  See the Fortify SCA User's Guide.

  -f <file>                   The file to which analysis results are written.
                              Default is stdout.

  -filter <file>              Specifies a filter file.  For more information,
                              see the Fortify SCA User's Guide.

  -findbugs                   Enable FindBugs integration for Java scans.
                              See "-java-build-dir".

  -java-build-dir <dir>       Used to specify one or more directories to which
                              Java sources have been compiled.  May also be
                              specified at build time.

  -no-default-issue-rules     See the Fortify SCA User's Guide.
  -no-default-sink-rules      See the Fortify SCA User's Guide.
  -no-default-source-rules    See the Fortify SCA User's Guide.

  -no-default-rules           Indicates that Fortify SCA should not use its
                              default rules.  Must be used in conjunction with
                              "-rules"

  -rules <specifier>          Specifies custom rules file or directory.  If a
                              directory is specified, all files ending in ".bin"
                              or ".xml" are included.
                              This option may be used multiple times.

  -quick                      Runs a quick scan. Quick scans complete faster at
                              the cost of reduced accuracy.

  -quiet                      Disables the command line progress bar.

  -scan                       Causes Fortify SCA to perform analysis against a
                              model.  The model must be specified with "-b".


Build Sessions

  -export-build-session <file.mbs>

                              Store the translated model specified by -b to the
                              specified file.

  -import-build-session <file.mbs>

                              Load the specified file into a build model.  If
                              the build ID of the model already exists in the
                              model registry, the import fails with the message
                              that a build already exists with that ID.


EXAMPLES


Build examples:
  Generic (Java, configuration, PHP, JavaScript, ASP/VBScript, VB6):
     sourceanalyzer -b mybuild .
     sourceanalyzer -b mybuild file1.java file2.java
     sourceanalyzer -b mybuild *.bas *.cls *.frm
     sourceanalyzer -b mybuild "site/**/*.php"

  ColdFusion translation:
     sourceanalyzer -b mybuild -source-base-dir /www/app "/www/app/**/*.cfm"

  SQL translation:
     sourceanalyzer -b mybuild -Dcom.fortify.sca.fileextensions.sql=PLSQL *.sql
     sourceanalyzer -b mybuild -Dcom.fortify.sca.fileextensions.sql=TSQL *.sql

  C/C++ builds:
     sourceanalyzer -b mybuild gcc -c test.c
     sourceanalyzer -b mybuild CL.EXE /o HelloWorld HelloWorld.c
     sourceanalyzer -b mybuild make
     sourceanalyzer -b mybuild devenv myproject.msproj /REBUILD

  Objective-C/C++ builds:
     sourceanalyzer -b mybuild clang -ObjC HelloWorld.m
     sourceanalyzer -b mybuild xcodebuild -project myproject.xcodeproj

  .NET builds:
     sourceanalyzer -b mybuild devenv myproj.sln /REBUILD
     sourceanalyzer -b mybuild msbuild /t:rebuild myproj.csproj

  Java specific builds:
     sourceanalyzer -b mybuild -cp lib/dependency.jar "src/**/*.java"
     sourceanalyzer -b mybuild -cp mytaglibs.jar webapp/*.jsp
     sourceanalyzer -b mybuild touchless ant

  J2EE specific builds:
     sourceanalyzer -b mybuild -cp "app/WEB-INF/lib/*.jar" app/*.jsp

Scan step:
     sourceanalyzer -b mybuild -scan -f results.fpr

Java build / scan with FindBugs support:
     sourceanalyzer -b fb -java-build-dir classes "src/**/*"
     sourceanalyzer -b fb -scan -findbugs -java-build-dir classes -f results.fpr

```
See Fortify SCA User's Guide for a complete explanation of each SCA option.


You can open a support case for Fortify products online using
our customer support system. This streamlined procedure is designed to
provide easier access and improved customer satisfaction.

Access your account at https://softwaresupport.softwaregrp.com/.


	/**
	 * Packaging - currenty only supporting jar or war.
	 * 
	 * @parameter expression="${project.packaging}"
	 * @readonly
	 * @required
	 */
	protected String packaging;

	/**
	 * @parameter expression="${project.build.directory}"
	 */
	protected String projectBuildDir;

	/**
	 * The set of dependencies required by the project
	 * 
	 * @parameter default-value="${project.dependencies}"
	 * @required
	 * @readonly protected List dependencies;
	 */
	protected List dependencies;

	/**
	 * location of the sourceanalyzer executable. Defaults to sourceanalyzer
	 * which will run the version on the path or fail if non exists.
	 * 
	 * @parameter expression="${fortify.sca.sourceanalyzer.executable}"
	 *            default-value="sourceanalyzer"
	 * @required
	 */
	protected String sourceanalyzer;
	
	/**
	 * Specifies the maximum heap size of JVM which runs Fortify SCA.
	 * The default value is 600 MB (-Xmx600M), which can be insufficient for
	 * large code bases. When specifying this option, ensure that you do not
	 * allocate more memory than is physically available, because this degrades
	 * performance. As a guideline, assuming no other memory intensive processes
	 * are running, do not allocate more than 2/3 of the available memory.
	 * 
	 * @parameter expression="${fortify.sca.Xmx}"
	 */
	protected String maxHeap;
	
	/**
	 * Specifies the initial and minimum heap size of JVM which runs Fortify SCA.
	 * The default value is 300MB (-Xms300M), which can be sufficient in most of cases.
	 * 
	 * @parameter expression="${fortify.sca.Xms}"
	 */
	protected String minHeap;

	/**
	 * Specifies the maximum permanent space size of JVM which runs Fortify SCA.
	 * The permanent space is the third part of Java memory, where are stored classes, methods etc.
	 * The default maximum value for the permanent generation is 64 MB (-XX:MaxPermSize=64M). 
	 * The permanent space is allocated as a separate memory region from the java heap, so increasing
	 * the permanent space will increase the overall memory requirements for the process. 
	 * 
	 * @parameter expression="${fortify.sca.PermGen}"
	 */
	protected String maxPermGen;

	/**
	 * Specifies the thread stack size of JVM runs Fortify SCA.
	 * Thread stacks are memory areas allocated for each Java thread for their internal use.
	 * The default value is 1MB (-Xss1M), which can be insufficient for large code bases.
	 * When encountering java.lang.StackOverflowError, increase the value gradually.
	 * For example, -Xss4M, -Xss8M.
	 * 
	 * @parameter expression="${fortify.sca.Xss}"
	 */
	protected String stackSize;
	
	/**
	 * If true sourceanalyzer will run in debug mode which is useful during
	 * troubleshooting
	 * 
	 * @parameter expression="${fortify.sca.debug}" default-value="false"
	 */
	protected boolean debug = false;

	/**
	 * If true sourceanalyzer will sends verbose status messages to the console.
	 * 
	 * @parameter expression="${fortify.sca.verbose}" default-value="false"
	 */
	protected boolean verbose;

	/**
	 * If true sourceanalyzer will sends verbose status messages to the console.
	 * 
	 * @parameter expression="${fortify.sca.machineOutput}"
	 *            default-value="false"
	 */
	protected boolean machineOutput;

	/**
	 * If true sourceanalyzer will write minimal messages to the console
	 * 
	 * @parameter expression="${fortify.sca.quiet}" default-value="true"
	 */
	protected boolean quiet;

	/**
	 * If true sourceanalyzer will print its version
	 * 
	 * @parameter expression="${fortify.sca.version}" default-value="true"
	 */
	protected boolean version;

	/**
	 * @parameter expression="${basedir}"
	 */
	protected String baseDir;

	/**
	 * build Id - will default to project name and version. If you are running
	 * an aggregate build use the -Dfortify.sca.buildId commandline
	 * configuration option instead to set the buildId for all modules.
	 * 
	 * @parameter expression="${fortify.sca.buildId}"
	 *            default-value="${project.artifactId}-${project.version}"
	 */
	protected String buildId;

	/**
	 * Runs Fortify SCA inside the 64-bit JRE. If no 64-bit JRE is available,
	 * Fortify SCA fails.
	 * 
	 * @parameter expression="${fortify.sca.64bit}" default-value="false"
	 */
	protected boolean jre64;

	/**
	 * The location of a .properties file, the contents of which are
	 * property-value pairs that are to be passed to sourceanalyzer in the form
	 * of -Dproperty=value, e.g.
	 * -Dcom.fortify.sca.DefaultJarsDirs=default_jar:../mylibs and
	 * -Dcom.fortify.sca.limiters.MaxChainDepth=10. Said file should be a
	 * standard Java properties file; refer to the Java documentation for more
	 * info on what this entails. Note that properties set in this manner will
	 * often take preference over Maven plug-in configuration properties such as
	 * defaultJarsPathString.
	 * 
	 * @parameter expression="${fortify.sca.properties.file}"
	 */
	private File scaPropertiesFile;
