# IB Pipeline Templates

This repository contains template pipelines and blocks for running common builds.

More information about [IB pipelines](./docs/pipeline/pipeline.md)

**Building pipelines**

- [Ant build](./docs/pipeline/ant_build.md)
- [Maven build](./docs/pipeline/maven_build.md) with [features](./docs/custom/maven_features.md)
- [Gradle build](./docs/pipeline/gradle_build.md)
- [Docker build](./docs/pipeline/docker_build.md)
- [Python build](./docs/pipeline/python_build.md)
- [Golang build](./docs/pipeline/go_build.md)
- [Msbuild build](./docs/pipeline/msbuild_build.md)
- [Maven docker build](./docs/pipeline/maven_docker_build.md)
- [Gradle docker build](./docs/pipeline/gradle_docker_build.md)
- [Python docker build](./docs/pipeline/python_docker_build.md)
- [Golang docker build](./docs/pipeline/go_docker_build.md)
- [Msbuild docker build](./docs/pipeline/msbuild_docker_build.md)

### SBC - fingerprint

For all IB pipelines templates fingerprint is enabled by default.

UBSCTL_FINGERPRINT_ARTIFACTS variable is generated dynamically for all release jobs.

## Gitlab with EVA integration

To integrate Gitlab with EVA you must be migrated to EVAv2. There is a dedicated [self-service](https://np683428127ao01.ubscloud-prod.msad.ubs.net/public/selfservice.ps1?tool=swev1) that will guide you through the migration.

Key notes:
  - to migrate from EVAv1.4 to EVAv2 you need APPSUPPORT role for your SWCI (BBS / HSJ - MICROSOFT AZURE CLOUD SRV STANDARD ROLES / HSJ-<ENV>_APPSUPP - WORKSPACE APPLICATION SUPPORT ROLE / <ATCODE>)
  - your service principals stored in EVAv1.4 will be rotated and current version will be stored only in EVAv2
  - in EVAv2 you can no longer create custom objects. You can only update objects (add k/v) that have been created through [ATTI](https://ubscloud.sharepoint.com/teams/EVA/SitePages/ATTi-Account-Onboarding-and-PWM.aspx).
  - **For special use cases there is a folder "other" available that can be used for non-ATTI managed objects**
  - After migrating to EVAv2 you have to create Gitlab roles for EVA. They can be generated/updated [here](https://np683428127ao01.ubscloud-prod.msad.ubs.net/public/selfservice.ps1?tool=glr3) and then verifed on [this](https://np683428127ao01.ubscloud-prod.msad.ubs.net/public/selfservice.ps1?tool=glr1) page.
  - There is a [native support](https://docs.gitlab.com/ee/ci/secrets/index.html#use-vault-secrets-in-a-ci-job) of Hashicorp Vault in Gitlab, but it will not work at UBS as Gitlab does not fully supporting HCV Enterprise.

## CI docker images - "backend" for pipelines

More information about [CI docker images](https://devcloud.ubs.net/ubs-ag/gt/ib-it/ib-tech-gb-cross-product/devops-tools/aa45252-gbdevops/docker-base-image) used to build projects.

### Release process

## Release artifact - promotion from DEV to QA

By default to build release artifact you need passed two requriments

- create tag on protected branch 
- create tag like **vX.Y.Z** or **vX.Y** or **vX.Y.Z.Q** example: v1.2.3 or v1.2 or v1.2.3.4

You could do that manually or via [API tag](https://docs.gitlab.com/ee/api/tags.html).

![manaul_creation](./docs/images/tag_creation.png)

**Who can create tag/release?**

By default release/tag could create Developers or Maintainers.

**Why tag?** 

By default all tags like **vX.Y.Z** or **vX.Y** will be [protected](https://docs.gitlab.com/ee/user/project/protected_tags.html).
Protected tags allow control over who has permission to create tags as well as preventing accidental update or deletion once created. Each rule allows you to match either an individual tag name, or use wildcards to control multiple tags at once.

**Is possible release others tags?**

Yes. Sometimes monorepo is used for many apps. So it is good create version/tag releated with app.
Example:
- artifatid -> **database** -> version -> **app1-v1.2.3**
- artifatid -> **database** -> version -> **app2-v1.2.3**
- artifatid -> **database** -> version -> **app3-v1.2.3**

Via Merge request developers/maintainers could request rules changes on .gitlab-ci.yml level.


## SBC - Secure Build Chain - release process - promotion from QA to UAT/PROD

To promote **release artifacts** to higher enviroments UAT/PRE-PROD/PROD artifacts should go via **SBC release registration process**

We need start **Release Registration process**

Under proper repo go to Deployments -> Releases - New Release

![release_creation](./docs/images/sbc1.png)

Make sure to create the release from the tag which you want promote, and in the release notes specify the CHG-SWC ID information. Add required information and press Create Release

![release_creation2](./docs/images/sbc2.png)

Notes:

 - a Change Ticket ID is required input for the Release Registration process
 - Creating a Release in GitLab triggers the Release Registration process (there is a GitLab Webhook configured to perform the registration when a release is created)

## NEO repository onboarding

[Examples:](./docs/onboarding/neo_examples.md)

**More info about NEO pipeline and relaese process please check [NEO documentaion](https://devcloud.ubs.net/ubs/ib/open-platforms-eco/digital-channels/dev-tools/ubs-neo/f35tools/gitlab-ci-templates)**

**[NEO maven pipeline](https://devcloud.ubs.net/ubs/ib/open-platforms-eco/digital-channels/dev-tools/ubs-neo/f35tools/gitlab-ci-templates/-/tree/master/java)**

**[NEO node pipeline](https://devcloud.ubs.net/ubs/ib/open-platforms-eco/digital-channels/dev-tools/ubs-neo/f35tools/gitlab-ci-templates/-/tree/master/node)**

## Pipeline customization

Exist option to extend basic template pipeline with additional jobs.

- [Secret scanning](/docs/custom/secret.md)
- [Sonar scanning](/docs/custom/sonar.md)
- [Fortify scanning](/docs/custom/fortify.md)
- [Jira check](/docs/custom/jira.md)
- [Sysdig scanning](/docs/custom/sysdig.md)

## Pipeline extensions

Every pipeline is extended by hidden jobs which everyone could used to extend template under every repo

- [UBS deploy](/docs/custom/ubsdeploy.md)
- [EVA](/docs/custom/eva.md)
- [DOMS](/docs/custom/doms.md)

## Global workflow for all templates

For simplicity I create one yaml file with all rules used accross all GB templates pipelines.
It give easy view of workflow used behind template

- [Global GB templates workflow](/global_gitlab_rules/common_rules.yml)

## Global stages for all templates

For simplicity I create one yaml file with all stages used accross all GB templates pipelines.
It give easy view of stages order used behind templates. The goal is not generate aditional stages under dedicated gitlab-ci.yaml in repo
I try cover many corner cases like (dev stages, release stages, dynamic pipelines, IaaC, DEV/QA deployment etc) Every main stage has pre_ stage where you could setup/prepare main stage and post_ stage where you could verify main stage.

- [Global GB templates stages](/global_gitlab_stages/global_stages.yml)

## Security + DevOps = DevSecOps

Small part of DevSecOps which we could improved via central gitlab ci templates.

It will be part where we focus on:

- central place where we collect all issues from UBS available security tools
- collect info about available security tools in UBS and NOT in UBS for SAST/DAST etc.. scanning
- integration part between Gitlab and security tools

[More here](/docs/devsecops/main.md)


## Gitlab CI/CD variables

CI/CD variables are part of the environment in which pipelines and jobs run. Variables can be used to customize jobs in GitLab CI/CD. GB gitlab pipelines used predefined CI/CD variables and Custom CI/CD variables.

Read more about [GB Custom CI/CD variables.](docs/gitlab_variables/variables.md)

## Gitlab CI Runners

On-prem Runners types and installation:

- [Solaris](https://sdlc-agile.swissbank.com/confluence/display/khubcoll/Solaris+Runner)
- [Solaris 10](https://sdlc-agile.swissbank.com/confluence/display/MFTUBS/Adding+Gitlab+Runner+on+Solaris+10)
- RHEL 7 & Windows

[Binaries](https://it4it-nexus-tp-repo.swissbank.com/#browse/browse:public-bin-crossplatform-gitlab-runner-latest)

[How install](https://ubs-ag.devcloud.ubs.net/gt/ise/docs/ubscloud/gotocloud/top-nav/developers/devcloud/gitlab/cicd/runners/registergitlabrunner.html)

[Advanced configuration](https://docs.gitlab.com/runner/configuration/advanced-configuration.html)

- [Azure shared runners](https://github.ldn.swissbank.com/pages/UBSCLOUD/cloud-home/top-nav/developers/devcloud/gitlab/cicd/runners/availablesharedrunners.html)
- [Azure shared "secure" runner](https://github.ldn.swissbank.com/pages/UBSCLOUD/cloud-home/top-nav/developers/devcloud/gitlab/cicd/runners/runnerstrategy.html)

## How to contribute

If you have something to contribute to this repository of templates, please fork this repository first. In your fork,
add your contribution or fix to the `main` branch and create a merge request. The merge request will be evaluated
by the current maintainers of the template library.
