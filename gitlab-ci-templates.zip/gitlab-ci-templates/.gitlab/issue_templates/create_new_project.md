 # Create new project/s
<!-- Do not include Masked Variable -->
<!-- Full path of your group including root namespace, i.e. for https://devcloud.ubs.net/ubsag/gt/ise/devops-platforms/gitlab, the group should be `ubs-ag/gt/ise/devops-platforms/gitlab` -->

Group: `ubs-ag/gt`

<!-- Overwrite existing variables. If key already exists, overwrite it with values in this issue. `True` or `False` -->

Overwrite: `False`

<!-- Variable definitions. Best copy and paste the example to avoid syntax errors.-->  
<!-- All fields must be defined for each variable -->
<!-- variable_type can be a "env var" (environment variable) or "file" (file type variable)  --> 
<!-- variable value must be in code block: ```value```-->
<!-- protected and masked must be either "true" or "false"-->
<!-- Make sure masked variables adhere to masking requirements: https://doc.gitlab.com/ee/ci/variables/README.html#masked-variable-requirements--> 

# Variables

## Variable 1

* "key": "variable_keyl"
* "variable_type": "env_var"
* "value": ```TEST 1```
* "protected": "false"
* "masked": "false"

## Variable 2

* "key": "variable_key2"
* "variable_type": "env_var"
* "value": ```TEST 2```
* "protected": "false"
* "masked": "false"

<!-- Don't change anything below this comment-->
/confidential 