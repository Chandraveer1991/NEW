# Jira title

it is very simple check which only checking title of merge request which should include jira issue related. **It is requrired check not possible skip.**

Example:

![jira](docs/images/dev_default.png)
